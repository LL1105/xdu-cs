-- 公交公司表
CREATE TABLE company
(
    id   INT PRIMARY KEY AUTO_INCREMENT, -- 公司ID
    name VARCHAR(100) NOT NULL           -- 公司名称
);

-- 车队表
CREATE TABLE fleet
(
    id         INT PRIMARY KEY AUTO_INCREMENT, -- 车队ID
    company_id INT          NOT NULL,          -- 公司ID，外键
    name       VARCHAR(100) NOT NULL,          -- 车队名称
    FOREIGN KEY (company_id) REFERENCES company (id)
);

-- 线路表
CREATE TABLE route
(
    id       INT PRIMARY KEY AUTO_INCREMENT, -- 线路ID
    name     VARCHAR(100) NOT NULL,          -- 线路名称
    fleet_id INT          NOT NULL,          -- 车队ID
    FOREIGN KEY (fleet_id) REFERENCES fleet (id)
);

-- 汽车表
CREATE TABLE bus
(
    id           INT PRIMARY KEY AUTO_INCREMENT, -- 汽车ID
    route_id     INT         NOT NULL,           -- 线路ID，外键
    seat_number  INT         NOT NULL,           -- 座位数
    plate_number VARCHAR(20) NOT NULL,           -- 车牌号
    company_id   INT         NOT NULL,           -- 公司ID，外键
    FOREIGN KEY (company_id) REFERENCES company (id),
    FOREIGN KEY (route_id) REFERENCES route (id)
);

-- 队长表
CREATE TABLE captain
(
    id       INT AUTO_INCREMENT PRIMARY KEY,     -- 队长ID
    name     VARCHAR(50) NOT NULL,               -- 队长姓名
    gender   VARCHAR(10) NOT NULL,               -- 性别
    fleet_id INT,                                -- 所属车队ID
    FOREIGN KEY (fleet_id) REFERENCES fleet (id) -- 外键，关联车队表
);
-- 在队长表上添加联合唯一约束，确保每个车队只有一个队长
ALTER TABLE captain
    ADD CONSTRAINT unique_fleet_id_captain_id UNIQUE (fleet_id, id);


-- 司机表
CREATE TABLE driver
(
    id       INT AUTO_INCREMENT PRIMARY KEY,     -- 司机ID
    name     VARCHAR(50) NOT NULL,               -- 司机姓名
    gender   VARCHAR(10) NOT NULL,               -- 性别
    route_id INT,                                -- 所属线路ID
    FOREIGN KEY (route_id) REFERENCES route (id) -- 外键，关联线路表
);
-- 给司机表添加唯一约束，确保每个司机只在一条线路上开车
ALTER TABLE driver
    ADD CONSTRAINT unique_route_id_driver_id UNIQUE (route_id, id);

-- 路队长表
CREATE TABLE route_captain
(
    id        INT AUTO_INCREMENT PRIMARY KEY,
    driver_id INT NOT NULL, -- 司机ID，外键
    route_id  INT NOT NULL, -- 线路ID，外键
    FOREIGN KEY (driver_id) REFERENCES driver (id),
    FOREIGN KEY (route_id) REFERENCES route (id)
);
-- 给路队长表添加唯一约束，确保每个路线只有一个路队长
ALTER TABLE route_captain
    ADD CONSTRAINT unique_route_id_driver_id UNIQUE (route_id, driver_id);

-- 站点表
CREATE TABLE station
(
    id       INT AUTO_INCREMENT PRIMARY KEY, -- 站点ID
    name     VARCHAR(100) NOT NULL,          -- 站点名
    route_id INT          NOT NULL,          -- 线路ID，外键
    FOREIGN KEY (route_id) REFERENCES route (id)
);


-- 违章信息表
CREATE TABLE violation
(
    id                  INT PRIMARY KEY AUTO_INCREMENT,                              -- 违章记录ID
    driver_id           INT      NOT NULL,                                           -- 违章司机ID，外键
    station_id          INT      NOT NULL,                                           -- 违章发生的站点ID, 外键
    violation_type      ENUM('闯红灯', '未礼让斑马线', '压线', '违章停车') NOT NULL, -- 违章类型
    violation_time      DATETIME NOT NULL,                                           -- 违章时间
    intput_by_type      ENUM('队长','路队长'),                                       -- 信息录入人类型
    input_by_captain_id INT NULL,                                                    -- 信息录入队长ID，外键
    input_by_driver_id  INT NULL,                                                    -- 信息录入路队长ID，外键
    FOREIGN KEY (input_by_driver_id) REFERENCES driver (id),
    FOREIGN KEY (input_by_captain_id) REFERENCES captain (id)
);



INSERT INTO company (name)
VALUES ('城市公交公司'),
       ('南方运输集团'),
       ('北方公共交通公司');

INSERT INTO fleet (company_id, name)
VALUES (1, '城市公交公司一队'),
       (1, '城市公交公司二队'),
       (2, '南方运输集团一队'),
       (3, '北方公共交通公司一队');

INSERT INTO route (name, fleet_id)
VALUES ('101路', 1),
       ('102路', 1),
       ('201路', 2),
       ('301路', 3),
       ('302路', 3);

INSERT INTO bus (route_id, seat_number, plate_number, company_id)
VALUES (1, 50, '京A12345', 1),
       (2, 50, '京A12346', 1),
       (3, 60, '粤B54321', 2),
       (4, 60, '冀C67890', 3),
       (5, 55, '冀C67891', 3);

INSERT INTO captain (name, gender, fleet_id)
VALUES ('张伟', '男', 1),
       ('李娜', '女', 2),
       ('王刚', '男', 3),
       ('赵敏', '女', NULL); -- 未分配车队

INSERT INTO driver (name, gender, route_id)
VALUES ('刘强', '男', 1),
       ('赵静', '女', 2),
       ('李四', '男', 3),
       ('王五', '男', 4),
       ('陈华', '女', 5);

INSERT INTO route_captain (driver_id, route_id)
VALUES (3, 3),
       (5, 5);

INSERT INTO station (name, route_id)
VALUES ('火车站', 1),
       ('市政府', 1),
       ('南方广场', 2),
       ('大学城', 3),
       ('北方公园', 4),
       ('机场', 5);

INSERT INTO violation (driver_id, station_id, violation_type, violation_time, intput_by_type, input_by_captain_id,
                       input_by_driver_id)
VALUES (1, 1, '闯红灯', '2024-11-28 08:30:00', '队长', 1, NULL),
       (2, 3, '未礼让斑马线', '2024-11-28 09:00:00', '路队长', NULL, 3),
       (3, 5, '压线', '2024-11-28 10:15:00', '队长', 2, NULL),
       (4, 6, '违章停车', '2024-11-28 11:20:00', '路队长', NULL, 5);