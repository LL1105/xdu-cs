package com.db.lab.lab.offline;

import com.db.lab.lab.offline.DBUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class FleetService {

    // 1. 录入司机信息
    public void addDriver(String name, String gender, int routeId) {
        String sql = "INSERT INTO driver (name, gender, route_id) VALUES (?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, gender);
            stmt.setInt(3, routeId);
            stmt.executeUpdate();
            System.out.println("司机信息录入成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. 录入汽车信息
    public void addBus(int routeId, int seatNumber, String plateNumber, int companyId) {
        String sql = "INSERT INTO bus (route_id, seat_number, plate_number, company_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, routeId);
            stmt.setInt(2, seatNumber);
            stmt.setString(3, plateNumber);
            stmt.setInt(4, companyId);
            stmt.executeUpdate();
            System.out.println("汽车信息录入成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 3. 录入违章信息
    public void addViolation(int driverId, int stationId, String violationType, LocalDateTime violationTime,
                             String inputByType, Integer inputByCaptainId, Integer inputByDriverId) {
        String sql = "INSERT INTO violation (driver_id, station_id, violation_type, violation_time, intput_by_type, input_by_captain_id, input_by_driver_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, driverId);
            stmt.setInt(2, stationId);
            stmt.setString(3, violationType);
            stmt.setTimestamp(4, Timestamp.valueOf(violationTime));
            stmt.setString(5, inputByType);
            stmt.setObject(6, inputByCaptainId, Types.INTEGER);
            stmt.setObject(7, inputByDriverId, Types.INTEGER);
            stmt.executeUpdate();
            System.out.println("违章信息录入成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 4. 查询某车队下的司机信息
    public List<Map<String, Object>> getDriversByFleet(int fleetId) {
        String sql = "SELECT d.id, d.name, d.gender FROM driver d " +
                "JOIN route r ON d.route_id = r.id " +
                "JOIN fleet f ON r.fleet_id = f.id " +
                "WHERE f.id = ?";
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, fleetId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", rs.getInt("id"));
                    map.put("name", rs.getString("name"));
                    map.put("gender", rs.getString("gender"));
                    result.add(map);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    // 5. 查询某司机某时间段的违章详细信息
    public List<Map<String, Object>> getViolationsByDriverAndTime(int driverId, LocalDateTime startTime, LocalDateTime endTime) {
        String sql = "SELECT * FROM violation WHERE driver_id = ? AND violation_time BETWEEN ? AND ?";
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, driverId);
            stmt.setTimestamp(2, Timestamp.valueOf(startTime));
            stmt.setTimestamp(3, Timestamp.valueOf(endTime));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", rs.getInt("id"));
                    map.put("type", rs.getString("violation_type"));
                    map.put("time", rs.getTimestamp("violation_time").toLocalDateTime());
                    result.add(map);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    // 6. 查询车队某时间段的违章统计信息
    public Map<String, Long> getFleetViolationStats(int fleetId, LocalDateTime startTime, LocalDateTime endTime) {
        String sql = "SELECT v.violation_type, COUNT(*) as count FROM violation v " +
                "JOIN driver d ON v.driver_id = d.id " +
                "JOIN route r ON d.route_id = r.id " +
                "JOIN fleet f ON r.fleet_id = f.id " +
                "WHERE f.id = ? AND v.violation_time BETWEEN ? AND ? " +
                "GROUP BY v.violation_type";
        Map<String, Long> result = new HashMap<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, fleetId);
            stmt.setTimestamp(2, Timestamp.valueOf(startTime));
            stmt.setTimestamp(3, Timestamp.valueOf(endTime));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.put(rs.getString("violation_type"), rs.getLong("count"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}
