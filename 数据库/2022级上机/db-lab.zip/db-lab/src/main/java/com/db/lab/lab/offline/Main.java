package com.db.lab.lab.offline;

import java.time.LocalDateTime;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        FleetService service = new FleetService();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println();
            System.out.println("----------------------------------------");
            System.out.println("请选择功能：");
            System.out.println("1. 录入司机信息");
            System.out.println("2. 录入汽车信息");
            System.out.println("3. 录入违章信息");
            System.out.println("4. 查询车队司机信息");
            System.out.println("5. 查询司机违章详细信息");
            System.out.println("6. 查询车队违章统计信息");
            System.out.println("0. 退出");

            int choice = scanner.nextInt();
            scanner.nextLine(); // 清除换行符

            switch (choice) {
                case 1:
                    System.out.print("请输入司机姓名: ");
                    String driverName = scanner.nextLine();
                    System.out.print("请输入司机性别: ");
                    String driverGender = scanner.nextLine();
                    System.out.print("请输入线路ID: ");
                    int routeId = scanner.nextInt();
                    service.addDriver(driverName, driverGender, routeId);
                    break;
                case 2:
                    System.out.print("请输入线路ID: ");
                    int busRouteId = scanner.nextInt();
                    System.out.print("请输入座位数: ");
                    int seatNumber = scanner.nextInt();
                    scanner.nextLine(); // 清除换行符
                    System.out.print("请输入车牌号: ");
                    String plateNumber = scanner.nextLine();
                    System.out.print("请输入公司ID: ");
                    int companyId = scanner.nextInt();
                    service.addBus(busRouteId, seatNumber, plateNumber, companyId);
                    break;
                case 3:
                    System.out.print("请输入司机ID: ");
                    int violationDriverId = scanner.nextInt();
                    System.out.print("请输入站点ID: ");
                    int stationId = scanner.nextInt();
                    scanner.nextLine(); // 清除换行符
                    System.out.print("请输入违章类型: ");
                    String violationType = scanner.nextLine();
                    System.out.print("请输入违章时间 (YYYY-MM-DDTHH:MM:SS): ");
                    String violationTime = scanner.nextLine();
                    LocalDateTime time = LocalDateTime.parse(violationTime);
                    System.out.print("请输入信息录入类型 (队长/路队长): ");
                    String inputType = scanner.nextLine();
                    System.out.print("请输入录入队长ID（如无输入0）: ");
                    int inputByCaptainId = scanner.nextInt();
                    System.out.print("请输入录入路队长ID（如无输入0）: ");
                    int inputByDriverId = scanner.nextInt();
                    service.addViolation(violationDriverId, stationId, violationType, time, inputType, inputByCaptainId == 0 ? null : inputByCaptainId, inputByDriverId == 0 ? null : inputByDriverId);
                    break;
                case 4:
                    System.out.print("请输入车队ID: ");
                    int fleetId = scanner.nextInt();
                    List<Map<String, Object>> drivers = service.getDriversByFleet(fleetId);
                    for (Map<String, Object> driver : drivers) {
                        System.out.println("司机ID: " + driver.get("id") + ", 姓名: " + driver.get("name") + ", 性别: " + driver.get("gender"));
                    }
                    break;
                case 5:
                    System.out.print("请输入司机ID: ");
                    int driverIdForViolations = scanner.nextInt();
                    System.out.print("请输入开始时间 (YYYY-MM-DDTHH:MM:SS): ");
                    String startTimeStr = scanner.next();
                    LocalDateTime startTime = LocalDateTime.parse(startTimeStr);
                    System.out.print("请输入结束时间 (YYYY-MM-DDTHH:MM:SS): ");
                    String endTimeStr = scanner.next();
                    LocalDateTime endTime = LocalDateTime.parse(endTimeStr);
                    List<Map<String, Object>> violations = service.getViolationsByDriverAndTime(driverIdForViolations, startTime, endTime);
                    for (Map<String, Object> violation : violations) {
                        System.out.println("违章ID: " + violation.get("id") + ", 违章类型: " + violation.get("type") + ", 违章时间: " + violation.get("time"));
                    }
                    break;
                case 6:
                    System.out.print("请输入车队ID: ");
                    int fleetIdForStats = scanner.nextInt();
                    System.out.print("请输入开始时间 (YYYY-MM-DDTHH:MM:SS): ");
                    String statStartTimeStr = scanner.next();
                    LocalDateTime statStartTime = LocalDateTime.parse(statStartTimeStr);
                    System.out.print("请输入结束时间 (YYYY-MM-DDTHH:MM:SS): ");
                    String statEndTimeStr = scanner.next();
                    LocalDateTime statEndTime = LocalDateTime.parse(statEndTimeStr);
                    Map<String, Long> stats = service.getFleetViolationStats(fleetIdForStats, statStartTime, statEndTime);
                    stats.forEach((key, value) -> System.out.println("违章类型: " + key + ", 次数: " + value));
                    break;
                case 0:
                    System.out.println("退出程序");
                    scanner.close();
                    return;
                default:
                    System.out.println("无效选择，请重新输入！");
            }
        }
    }
}
