package com.db.lab.lab1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MysqlConnect {

    public static void main(String[] args) {
        // 数据库连接信息
        String url = "jdbc:mysql://gitgle.mysql.polardb.rds.aliyuncs.com:3306/lab";
        String username = "gitgle";
        String password = "gitgle_1024";

        // 数据库连接对象
        Connection connection = null;

        try {
            // 1. 加载驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. 建立连接
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("数据库连接成功！");

            // 3. 执行查询示例
            String query = "SELECT * FROM user";
            PreparedStatement statement = connection.prepareStatement(query);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");

                System.out.printf("ID: %d, Name: %s%n", id, name);
            }

        } catch (ClassNotFoundException e) {
            System.err.println("驱动加载失败：" + e.getMessage());
        } catch (SQLException e) {
            System.err.println("数据库连接失败：" + e.getMessage());
        } finally {
            // 4. 关闭连接
            try {
                if (connection != null) {
                    connection.close();
                    System.out.println("数据库连接已关闭。");
                }
            } catch (SQLException e) {
                System.err.println("关闭连接失败：" + e.getMessage());
            }
        }
    }
}
