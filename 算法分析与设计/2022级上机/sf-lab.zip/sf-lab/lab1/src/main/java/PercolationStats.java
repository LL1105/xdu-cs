import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * PercolationStats类用于进行渗透系统的统计分析
 * 它提供了一种计算渗透阈值概率的方法，并能够给出统计置信区间
 */
public class PercolationStats{

    // 网格的大小
    private int N;

    // 实验的次数
    private int T;

    // 存储每次实验中开放的站点比例
    private List<Double> x = new ArrayList<>();

    /**
     * 构造函数，初始化PercolationStats对象
     *
     * @param N 网格的大小，必须大于0
     * @param T 实验的次数，必须大于0
     * @throws IllegalArgumentException 如果N或T不大于0，则抛出此异常
     */
    public PercolationStats(int N, int T) {
        if(N <= 0 || T <= 0){
            throw new IllegalArgumentException("参数必须大于0");
        }
        this.N = N;
        this.T = T;
    }

    /**
     * 计算样本均值
     *
     * @return 样本均值
     */
    public double mean() {
        double meanSum = 0;
        for(int i=0;i<x.size();i++){
            meanSum += x.get(i);
        }
        return meanSum/T;
    }

    /**
     * 计算样本标准差
     *
     * @return 样本标准差
     */
    public double stddev() {
        double mean = mean();
        double stddevSum = 0;
        for(int i=0;i<x.size();i++){
            stddevSum += Math.pow(x.get(i)-mean,2);
        }
        return Math.sqrt(stddevSum/(T-1));
    }

    /**
     * 计算置信区间的下限
     *
     * @return 置信区间的下限
     */
    public double confidenceLo() {
        double mean = mean();
        double stddev = stddev();
        return mean - 1.96*stddev/Math.sqrt(T);
    }

    /**
     * 计算置信区间的上限
     *
     * @return 置信区间的上限
     */
    public double confidenceHi() {
        double mean = mean();
        double stddev = stddev();
        return mean + 1.96*stddev/Math.sqrt(T);
    }

    /**
     * 开始进行渗透实验
     * 它会创建一个指定大小的网格，并随机开放站点，直到系统渗透
     * 实验重复指定次数，并收集每次实验中开放的站点比例
     */
    public void start(Percolation percolation){
        System.out.println("开始进行实验，网格数为：" + N + "*" + N + "进行实验次数为：" + T);
        for(int i = 0; i < T; i++){
            int openNum = 0;
            while(!percolation.percolates()){
                Random random = new Random();
                int row = random.nextInt(N)+1;
                int col = random.nextInt(N)+1;
                if(!percolation.isOpen(row, col)){
                    percolation.open(row, col);
                    openNum++;
                }
            }
            x.add((double)openNum/(N*N));
        }
        System.out.println("样本均值：" + mean());
        System.out.println("样本方差：" + stddev());
        System.out.println("置信区间：" + confidenceLo() + " ~ " + confidenceHi());
    }

    /**
     * 主函数，用于运行渗透实验
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        List<List<Integer>> list = new ArrayList<>();
        list.add(Arrays.asList(200,100));
        List<Percolation> percolationList = new ArrayList<>();
        for(int i=0;i<list.size();i++){
            percolationList.add(new PercolationUF(list.get(i).get(0)));
            percolationList.add(new PercolationQUF(list.get(i).get(0)));
            percolationList.add(new PercolationWQUF(list.get(i).get(0)));
        }
        for(Percolation percolation : percolationList){
            System.out.println("===========================================================================");
            System.out.println("当前使用的算法是：" + percolation.getType());
            long start = System.currentTimeMillis();
            PercolationStats percolationStats1 = new PercolationStats(200,100);
            percolationStats1.start(percolation);
            long end = System.currentTimeMillis();
            System.out.println("运行时间：" + (end - start) + "ms");
        }
    }
}
