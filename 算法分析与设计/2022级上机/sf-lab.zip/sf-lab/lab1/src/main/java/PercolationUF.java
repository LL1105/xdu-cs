import edu.princeton.cs.algs4.UF;

/**
 * Percolation类用于模拟渗透系统，通过一个二维网格来表示
 */
public class PercolationUF implements Percolation{

    // 二维数组grid表示网格，0表示关闭，1表示打开且不饱和，2表示打开且饱和
    private final int[][] grid;

    // 网格的大小
    private final int N;

    // UF对象用于处理网格中的连通性
    private final UF uf;

    /**
     * 构造函数，初始化一个N*N的网格
     * @param N 网格的大小
     */
    public PercolationUF(int N){
        if(N <= 0){
            throw new IllegalArgumentException("N必须大于0");
        }
        this.grid = new int[N][N];
        this.N = N;
        this.uf = new UF(N*N+2);
        // 将顶部的所有单元与虚拟顶点（0）连接
        for(int i=0;i<N;i++){
            uf.union(0, getUFId(0,i));
        }
        // 将底部的所有单元与虚拟底点（N*N+1）连接
        for(int i=0;i<N;i++){
            uf.union(N*N+1, getUFId(N-1,i));
        }
    }

    /**
     * 将二维坐标转换为一维，以便在UF对象中使用
     * @param x x坐标
     * @param y y坐标
     * @return 一维坐标
     */
    private int getUFId(int x, int y){
        return (x*N + y + 1);
    }

    /**
     * 打开指定位置的单元，并与周围的打开单元连接
     * @param i 行号
     * @param j 列号
     */
    public void open(int i, int j) {
        if (i < 1 || j < 1 || j > N || i > N){
            throw new IndexOutOfBoundsException("参数范围错误");
        }
        grid[i-1][j-1] = 1;
        int dx[] = {0,0,-1,1};
        int dy[] = {1,-1,0,0};
        // 遍历周围的四个单元
        for (int x = 0; x<4;x++){
            if (i+dx[x] >= 1 && i+dx[x] <= N && j+dy[x] >= 1 && j+dy[x] <= N && isOpen(i+dx[x],j+dy[x])){
                uf.union(getUFId(i+dx[x]-1,j+dy[x]-1), getUFId(i-1,j-1));
            }
        }
    }

    @Override
    public String getType() {
        return "UF";
    }

    /**
     * 判断指定位置的单元是否打开
     * @param i 行号
     * @param j 列号
     * @return 如果打开返回true，否则返回false
     */
    public boolean isOpen(int i, int j) {
        if (i < 1 || j < 1 || j > N || i > N){
            throw new IndexOutOfBoundsException("参数范围错误");
        }
        return grid[i-1][j-1] == 1;
    }

    /**
     * 判断指定位置的单元是否饱和
     * @param i 行号
     * @param j 列号
     * @return 如果饱和返回true，否则返回false
     */
    public boolean isFull(int i, int j) {
        if (i < 1 || j < 1 || j > N || i > N){
            throw new IndexOutOfBoundsException("参数范围错误");
        }
        return grid[i-1][j-1] == 2;
    }

    /**
     * 判断系统是否渗透，即虚拟顶点和虚拟底点是否连通
     * @return 如果渗透返回true，否则返回false
     */
    public boolean percolates() {
        return uf.connected(0, N*N+1);
    }

    /**
     * 主函数用于测试Percolation类
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        PercolationUF percolationUF = new PercolationUF(20);
        percolationUF.open(1,1);
        System.out.println(percolationUF.isOpen(1,1));
        System.out.println(percolationUF.isFull(1,1));
        System.out.println(percolationUF.percolates());
    }
}
