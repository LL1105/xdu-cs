public interface Percolation {
    boolean percolates();

    boolean isOpen(int row, int col);

    void open(int row, int col);

    String getType();
}
