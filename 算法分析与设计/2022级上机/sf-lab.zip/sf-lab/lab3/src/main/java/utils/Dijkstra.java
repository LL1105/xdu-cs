package utils;

import entity.Edge;
import entity.Graph;

import java.util.*;

public class Dijkstra {
    private final Graph graph;
    double[] distances;
    int[] previous;
    Set<Integer> visited;

    public Dijkstra(Graph graph) {
        int n = graph.points.length;
        this.graph = graph;
        this.visited = new HashSet<>();
        distances = new double[n];
        previous = new int[n];
        Arrays.fill(distances, Double.POSITIVE_INFINITY);
        Arrays.fill(previous, -1);
    }

    public void init(int source) {
        // 只初始化遍历过的点
        for(Integer i : visited){
            distances[i] = Double.POSITIVE_INFINITY;
            previous[i] = -1;
        }
        distances[source] = 0;
        visited.clear();
    }

    public double findShortestPath(int source, int target) {
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingDouble(a -> a[1]));
        pq.add(new int[]{source, 0});

        while (!pq.isEmpty()) {
            int[] curr = pq.poll();
            int currentNode = curr[0];
            double currentDistance = curr[1];

            visited.add(currentNode);

            if (currentDistance > distances[currentNode]) {
                continue; // 忽略已被优化的路径
            }

            // 当遍历到目标点后结束
            if (currentNode == target) {
                return distances[target];
            }

            for (Edge edge : graph.adjList.get(currentNode)) {
                int neighbor = edge.to;
                double newDist = distances[currentNode] + edge.weight;
                if (newDist < distances[neighbor]) {
                    distances[neighbor] = newDist;
                    previous[neighbor] = currentNode;
                    pq.add(new int[]{neighbor, (int) newDist});
                }
            }
        }

        return Double.POSITIVE_INFINITY; // 无路径
    }

    public List<Integer> reconstructPath(int target, int source) {
        List<Integer> path = new ArrayList<>();
        for (int at = target; at != source; at = previous[at]) {
            path.add(at);
        }
        path.add(source);
        Collections.reverse(path);
        return path;
    }
}
