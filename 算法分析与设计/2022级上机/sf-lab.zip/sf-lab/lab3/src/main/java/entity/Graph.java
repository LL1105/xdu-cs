package entity;

import java.util.ArrayList;
import java.util.List;

public class Graph {
    public List<List<Edge>> adjList;
    public Point[] points;

    public Graph(int n) {
        adjList = new ArrayList<>();
        points = new Point[n];
        for (int i = 0; i < n; i++) {
            adjList.add(new ArrayList<>());
        }
    }

    public void addEdge(int from, int to, double weight) {
        adjList.get(from).add(new Edge(from, to, weight));
    }

    public void setPoint(int id, double x, double y) {
        points[id] = new Point(id, x, y);
    }
}