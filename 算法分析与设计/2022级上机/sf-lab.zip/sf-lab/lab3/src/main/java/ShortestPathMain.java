import entity.Graph;
import utils.Dijkstra;
import utils.GraphParser;

import java.io.*;
import java.util.*;

public class ShortestPathMain {

    private static final int MAX_QUERIES = 1000;

    public static void main(String[] args) throws IOException {
        // 输入文件路径
        String filename = "实验三-输入数据usamap.txt";

        // 解析图
        Graph graph = GraphParser.parseGraph(filename);

        Dijkstra dijkstra = new Dijkstra(graph);

        // 开始批量最短路径查询
        int points = graph.points.length;
        Random random = new Random();
        long start = System.currentTimeMillis();
        for(int i=0; i<MAX_QUERIES; i++){
            int source = random.nextInt(points);
            int target = random.nextInt(points);

            System.out.println("----------------------------------------------------------------");
            System.out.println("源点:"+ source + "--->" + "目标点:" + target);
            dijkstra.init(source);

            double distance = dijkstra.findShortestPath(source, target);

            System.out.println("最短距离: " + distance);
            System.out.println("最短路径: " + (distance == Double.POSITIVE_INFINITY ? null : dijkstra.reconstructPath(target,source)));
        }
        System.out.println("----------------------------------------------------------------");
        long end = System.currentTimeMillis();
        System.out.println("运行时间: " + (end - start) + "ms");
    }
}
