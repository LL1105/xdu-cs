package utils;

import entity.Graph;

import java.io.*;

public class GraphParser {

    public static Graph parseGraph(String filename) throws IOException {
        // 使用类加载器加载文件
        InputStream inputStream = GraphParser.class.getClassLoader().getResourceAsStream(filename);
        if (inputStream == null) {
            throw new FileNotFoundException("无法在类路径下找到文件: " + filename);
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        // 解析顶点数和边数
        String[] firstLine = reader.readLine().split(" ");
        int vertices = Integer.parseInt(firstLine[0]);
        int edges = Integer.parseInt(firstLine[1]);

        // 构建一个图
        Graph graph = new Graph(vertices);

        // 解析所有顶点
        for (int i = 0; i < vertices; i++) {
            String[] vertexLine = reader.readLine().trim().split("\\s+");
            if(vertexLine.length != 3) continue;
            int id = Integer.parseInt(vertexLine[0]);
            double x = Double.parseDouble(vertexLine[1]);
            double y = Double.parseDouble(vertexLine[2]);
            graph.setPoint(id, x, y);
        }

        // 解析所有边
        for (int i = 0; i < edges; i++) {
            String[] edgeLine = reader.readLine().trim().split("\\s+");
            if(edgeLine.length != 2) continue;
            int from = Integer.parseInt(edgeLine[0]);
            int to = Integer.parseInt(edgeLine[1]);
            double weight = graph.points[from].euclideanDistance(graph.points[to]);
            graph.addEdge(from, to, weight);
            graph.addEdge(to, from, weight); // 假设为无向图
        }

        // 关闭文件流
        reader.close();
        return graph;
    }
}
