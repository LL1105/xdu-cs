import java.util.Random;

public class SortingPerformanceTest {

    public static void main(String[] args) {
        int[] sizes = {10000}; // 数据规模
        int numTrials = 10; // 每种数据运行的次数

        for (int size : sizes) {
            System.out.println("Array Size: " + size);

            // 生成随机数组
            int[][] arrays = new int[numTrials][size];
            Random rand = new Random();
            for (int i = 0; i < numTrials; i++) {
                for (int j = 0; j < size; j++) {
                    arrays[i][j] = rand.nextInt();
                }
            }

            // 测试插入排序
            testSorting("IS", arrays, (arr) -> InsertionSort.insertionSort(arr));

            // 测试自顶向下归并排序
            testSorting("TDM", arrays, (arr) -> TopDownMergesort.mergesort(arr));

            // 测试自底向上归并排序
            testSorting("BUM", arrays, (arr) -> BottomUpMergesort.mergesort(arr));

            // 测试随机快速排序
            testSorting("RQ", arrays, (arr) -> RandomQuicksort.quicksort(arr, 0, arr.length - 1));

            // 测试Dijkstra 3-路划分快速排序
            testSorting("QD3P", arrays, (arr) -> Dijkstra3WayQuicksort.quicksort(arr, 0, arr.length - 1));
        }
    }

    // 用于测试排序算法的性能
    private static void testSorting(String sortName, int[][] arrays, SortingAlgorithm algorithm) {
        double totalTime = 0;
        Runtime runtime = Runtime.getRuntime();
        for (int i = 0; i < arrays.length; i++) {
            if(i % arrays.length == 0){
                System.out.println("===========================================================");
            }
            int[] arr = arrays[i].clone(); // 克隆数组，避免排序影响后续测试
            long startTime = System.nanoTime();
            algorithm.sort(arr);
            long endTime = System.nanoTime();
            System.out.println(sortName + " Run" + (i+1) + " : " + (endTime - startTime)/1_000_000.0 + " ms");
            totalTime += (endTime - startTime)/1_000_000.0;
        }
        System.out.println(sortName + " Average : " + totalTime / arrays.length + " ms");
    }

    // 排序算法接口
    @FunctionalInterface
    interface SortingAlgorithm {
        void sort(int[] arr);
    }
}
