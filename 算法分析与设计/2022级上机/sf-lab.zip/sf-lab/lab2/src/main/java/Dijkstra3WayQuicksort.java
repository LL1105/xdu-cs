public class Dijkstra3WayQuicksort {
    public static void quicksort(int[] arr, int low, int high) {
        if (low >= high) return;
        
        int lt = low, i = low + 1, gt = high;
        int pivot = arr[low];
        
        while (i <= gt) {
            if (arr[i] < pivot) swap(arr, lt++, i++);
            else if (arr[i] > pivot) swap(arr, i, gt--);
            else i++;
        }
        
        quicksort(arr, low, lt - 1);
        quicksort(arr, gt + 1, high);
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
